//Помощь при создании потоков оказал материал -> https://evileg.com/ru/post/151/

#include "starthttpserver.h"

#include <QString>
#include <QStandardPaths>
#include <auroraapp.h>
#include "src/mongoose.h"
#include <QThread>

StartHTTPServer::StartHTTPServer()
{
}

void ev_handler(struct mg_connection *c, int ev, void *ev_data) {
  if (ev == MG_EV_HTTP_MSG) {
    struct mg_http_message *hm = (struct mg_http_message *) ev_data;
    struct mg_http_serve_opts opts = { .root_dir = (Aurora::Application::getPath(PackageFilesLocation)+"/qml/pages/www").toLocal8Bit().data() };
    mg_http_serve_dir(c, hm, &opts);
  }
}

void StartHTTPServer::run() //запуск сервера mongoose в потоке Qthread(см. документацию на mongoose embed)
{
    struct mg_mgr mgr;  // Declare event manager
    mg_mgr_init(&mgr);  // Initialise event manager
    mg_http_listen(&mgr, "http://localhost:8985/", ev_handler, NULL);  // Setup listener

    for (;;) {          // Run an infinite event loop
        mg_mgr_poll(&mgr, 1000);
   }

}
