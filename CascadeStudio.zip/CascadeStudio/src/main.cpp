#include <auroraapp.h>
#include <QtQuick>

#include <QThread>
#include <QString>
#include <QStandardPaths>
#include <auroraapp.h>
#include "mongoose.h"

#include "starthttpserver.h"


int main(int argc, char *argv[])
{
    StartHTTPServer httpd; //запуск веб-сервера в потоке QThread
    httpd.start();

    QScopedPointer<QGuiApplication> application(Aurora::Application::application(argc, argv));
    application->setOrganizationName(QStringLiteral("ru.mastercond"));
    application->setApplicationName(QStringLiteral("CascadeStudio"));


    QScopedPointer<QQuickView> view(Aurora::Application::createView());
    view->setSource(Aurora::Application::pathTo(QStringLiteral("qml/CascadeStudio.qml")));
    view->show();

    return application->exec();

}
