//Помощь при создании потоков оказал материал -> https://evileg.com/ru/post/151/

#ifndef STARTHTTPSERVER_H
#define STARTHTTPSERVER_H

#include <QString>
#include <QStandardPaths>
#include <auroraapp.h>
#include "src/mongoose.h"
#include <QThread>

class StartHTTPServer: public QThread
{

public:
explicit StartHTTPServer();

void run();
};

#endif // STARTHTTPSERVER_H


