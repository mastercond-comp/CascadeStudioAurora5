<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru">
<context>
    <name>DefaultCoverPage</name>
    <message>
        <location filename="../qml/cover/DefaultCoverPage.qml" line="10"/>
        <source>CascadeStudio</source>
        <translation>CascadeStudio</translation>
    </message>
</context>
</TS>
